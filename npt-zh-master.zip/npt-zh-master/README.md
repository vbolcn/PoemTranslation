This is the main code for paper "Neural translation of modern Chinese poetry and lyrics"

python interactive.py -path_checkpoint "checkpoints/checkpoint_best.pt" -data_bin "data-bin/" -beam 5 -nbest 5 -poem '娘子'
